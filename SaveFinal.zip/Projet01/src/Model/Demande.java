package Model;

import constante.Constantes;

/**
 * Calss Demande contient un etage et une direction
 *
 */
public class Demande {

	float etage = 0;
	String direction = Constantes.HAUT;

	/**
	 * Demande
	 * 
	 * @param etage
	 * @param direction
	 */
	public Demande(float etage, String direction) {
		this.etage = etage;
		this.direction = direction;
	}

	/**
	 * getEtage()
	 * 
	 * @return float
	 */
	public float getEtage() {
		return etage;
	}

	/**
	 * setEtage
	 * 
	 * @param etage
	 */
	public void setEtage(float etage) {
		this.etage = etage;
	}

	/**
	 * getDirection()
	 * 
	 * @return String
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * setDirection
	 * 
	 * @param direction
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}

}
