package Model;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

import constante.Constantes;

/**
 * Class AscenseurModel
 *
 */

public class AscenseurModel extends Observable {

	private boolean isArretUrgence = false;
	private float etageDestination;
	private float etageActuel;


	public String resultatDirection = "";

	public String directionAsc = Constantes.HAUT;

	public Demande d;
	
	public int compeurTentativedirection = 0;

	// Liste des demandes des utilisateurs de l'exterieur de l'ascenseur
	private List<Demande> demandeEtageDeExterieur;
	
	

	// Liste des demandes des utilisateurs de l'exterieur de l'ascenseur
	private List<Float> demandeEtageDeInterieur;

	private String etatPorte = Constantes.EtatPorteFermer;

	// Nombre d'étage initialisé à 5
	public int nbEtages = 5;
	
	public boolean MonterServiForImge = false;
	public boolean DecenteServiForImge = false;
	public boolean InterieurServiForImge = false;

	public AscenseurModel() {

		super();

		// Initialisation
		etatPorte = Constantes.EtatPorteFermer;
		etageDestination = -1;

		etageActuel = 0;

		demandeEtageDeExterieur = new ArrayList<Demande>();
		demandeEtageDeInterieur = new ArrayList<Float>();
	}

	/**
	 * Méthode qui notifie la vue (l'obsever) pour mettre à jour les valeurs à
	 * afficher. Cette méthode est appelée après chaque changement
	 */
	public void notifierLaVu() {
		setChanged();
		notifyObservers();
	}

	public void notifierLaVu(boolean stopArr) {
		setChanged();
		notifyObservers(new Boolean(true));
	}

	/**
	 * Methode monter permet le déplacement de l'ascenseur vers le haut avec une
	 * unité de mouvement. L'unité de mouvement est égale à 0.5 (etage). A
	 * l'approche de l'étage de destination devient 0.1 pour ralentir la vitesse
	 * de l'ascenseur
	 */
	public void monter() {

		DecimalFormat decimalFormat = new DecimalFormat("#.#");

		float unite = Constantes.UniteDeMouvement;

		if ((Math.abs(this.etageActuel - this.etageDestination)) < 1.0) {
			unite = Constantes.UniteDeMouvementLente;
		}
		this.etageActuel = this.etageActuel + unite;
		this.etageActuel = Float.valueOf(decimalFormat.format(this.etageActuel).replaceAll(",", "."));

		System.out.println("Monter " + this.etageActuel);
	}

	/**
	 * Methode descendre permet le déplacement de l'ascenseur vers le bas avec
	 * une unité de mouvement. L'unité de mouvement est égale à 0.5 (etage). A
	 * l'approche de l'étage de destination devient 0.1 pour ralentir la vitesse
	 * de l'ascenseur
	 */
	public void descendre() {

		DecimalFormat df = new DecimalFormat("#.#");

		float unite = Constantes.UniteDeMouvement;

		if ((Math.abs(this.etageActuel - this.etageDestination)) < 1.0) {
			unite = Constantes.UniteDeMouvementLente;
		}
		this.etageActuel = this.etageActuel - unite;
		this.etageActuel = Float.valueOf(df.format(this.etageActuel).replaceAll(",", "."));
		System.out.println("Descendre : " + this.etageActuel);
	}

	/**
	 * Méthode arretUrgence arrête immédiatement l'ascenseur (quel que soit sa
	 * position) dès qu'un utilisateur appuit sur le bouton
	 */
	public void arretUrgence() {
		this.isArretUrgence = true;
		notifierLaVu();
	}

	/**
	 * Méthode annulerArretUrgnce annule l'arrêt d'urgence (dès que le
	 * technicien appuit sur le bouton), si l'ascenseur est arrêté entre deux
	 * etages il se positionne à l'étage au-dessous
	 */
	public void annulerArretUrgence() {
		this.isArretUrgence = false;
		notifierLaVu(true);
	}

	/**
	 * Methode ajouterDemandeExterieur ajoute les demandes des utilisateurs
	 * exterieur et vérifie si cette dernière n'est pas déjà enregistrée (si
	 * elle ne l'est pas il l'ajoute).
	 * 
	 * @param etage
	 *            - Etage de l'exterieur demandé
	 * @param typeDemande
	 *            - HAUT: l'utilisateur de l'exterieur veut monter - BAS :
	 *            l'utilisateur à l'exterieur de l'ascensceur veut Descendre
	 */
	public void ajouterDemandeExterieur(float etage, String typeDemande) {

		boolean etageExistant = false;
		for (int i = 0; i < this.demandeEtageDeExterieur.size(); i++) {
			if (etage == (float) this.demandeEtageDeExterieur.get(i).getEtage()
					&& this.demandeEtageDeExterieur.get(i).getDirection() == typeDemande) {
				etageExistant = true;
			}
		}
		if (!etageExistant) {
			this.demandeEtageDeExterieur.add(new Demande(etage, typeDemande));
		}

	}

	/**
	 * Methode ajuoterDemandeEtageInterieur.Ajoute les etages demandés par les
	 * urilisateurs à l'interieur de la cabine (si cet étage est demandé pour la
	 * première fois elle l'ajoute sinon s'il est déjà enregistré et il n'est
	 * pas encore satisfé elle ignore la demande d'ajout).
	 * 
	 * @param etage
	 *            - Etage de déstnation
	 */
	public void ajouterDemandeEtageInterieur(float etage) {
		boolean nonAjouter = true;
		for (int i = 0; i < this.demandeEtageDeInterieur.size(); i++) {
			if (etage == (float) this.demandeEtageDeInterieur.get(i)) {
				nonAjouter = false;
			}
		}
		if (nonAjouter) {
			this.demandeEtageDeInterieur.add(etage);
		}
	}

	/**
	 * Methode nextEtageInterieur,float return le prchain etage interieur que
	 * l'ascensseur doit satifrère
	 * 
	 * @param etage
	 * @param direction
	 * @return float
	 */
	public float nextEtageInterieur(float etage, String direction) {

		float next = -1;
		for (int i = 0; i < this.demandeEtageDeInterieur.size(); i++) {
			// Monter
			if (Constantes.HAUT.equals(direction)) {
				if (etage <= (float) this.demandeEtageDeInterieur.get(i)) {
					if (next == -1) {
						next = (float) this.demandeEtageDeInterieur.get(i);
					}

					if (next > (float) this.demandeEtageDeInterieur.get(i)) {
						next = (float) this.demandeEtageDeInterieur.get(i);
					}
				}
			}

			// Decente
			if (Constantes.BAS.equals(direction)) {
				if (etage >= (float) this.demandeEtageDeInterieur.get(i)) {
					if (next == -1) {
						next = (float) this.demandeEtageDeInterieur.get(i);
					}
					if (next < (float) this.demandeEtageDeInterieur.get(i)) {
						next = (float) this.demandeEtageDeInterieur.get(i);
					}

				}
			}
		}
		return next;
	}

	/**
	 * Méthode nextDemande détermine la prchaine destination ou l'ascenseur doit
	 * s'arreter
	 * 
	 * @param directionActuel
	 * @return String - Pour donner la direction de l'ascenseur (Monter ou
	 *         Déscendre)
	 */
	public String nextDemande(String directionActuel) {

		float maDestination = -1;
		String resultat = "";

		float etageActuel = getEtageActuel();
		Float nextInterieur = nextEtageInterieur(etageActuel, directionActuel);
		Demande demandeMonterSup = demandeMonterSup(demandeEtageDeExterieur);
		Demande demandeMonterInf = demandeMonterInf(demandeEtageDeExterieur);
		Demande demabdeDecenteSup = demandeDecenteSup(demandeEtageDeExterieur);
		Demande demabdeDecenteInf = demandeDecenteInf(demandeEtageDeExterieur);

		if (Constantes.HAUT.equals(directionActuel)) {
			resultat = Constantes.MONTER;

			if (nextInterieur != -1) {
				maDestination = nextInterieur;

			}

			if (demandeMonterSup != null) {
				maDestination = demandeMonterSup.getEtage();
			} else {
				if (demabdeDecenteSup != null && (nextInterieur == -1  || nextInterieur <= etageActuel) ) {
					maDestination = demabdeDecenteSup.getEtage();
					resultat = Constantes.DESCENDRE;
				}
			}

			if (nextInterieur != -1 && demandeMonterSup != null && nextInterieur < demandeMonterSup.getEtage()
					&& nextInterieur > getEtageActuel()) {
				maDestination = nextInterieur;
			}

			if (nextInterieur != -1 && demabdeDecenteSup != null && nextInterieur < demabdeDecenteSup.getEtage()
					&& nextInterieur > getEtageActuel()) {
				maDestination = nextInterieur;
				resultat = Constantes.DESCENDRE;
			}

		}

		if (Constantes.BAS.equals(directionActuel)) {
			resultat = Constantes.DESCENDRE;
			if (nextInterieur != -1) {
				maDestination = nextInterieur;
			}

			if (demabdeDecenteInf != null) {
				maDestination = demabdeDecenteInf.getEtage();
			} else {
				if (demandeMonterInf != null   && (nextInterieur == -1  || nextInterieur >= etageActuel)) {
					maDestination = demandeMonterInf.getEtage();
					resultat = Constantes.MONTER;
				}
			}

			if (nextInterieur != -1 && demabdeDecenteInf != null && nextInterieur > demabdeDecenteInf.getEtage()
					&& nextInterieur < getEtageActuel()) {
				maDestination = nextInterieur;
			}

			if (nextInterieur != -1 && demandeMonterInf != null && nextInterieur > demandeMonterInf.getEtage()
					&& nextInterieur < getEtageActuel()) {
				maDestination = nextInterieur;
				resultat = Constantes.MONTER;
			}
		}

		if (maDestination == -1) {
			compeurTentativedirection++;
		} else {
			compeurTentativedirection = 0;
		}

		System.out.println("direction actuel : " + directionActuel);
		this.setEtageDestination(maDestination);
		return resultat;

	}

	/**
	 * Récupère la demande de monter superieur à l'étage actuel la plus proche
	 * 
	 * @param demandeEtageDeExterieur2
	 * @return Demande
	 */
	private Demande demandeMonterSup(List<Demande> demandeEtageDeExterieur2) {
		Demande min = new Demande(100, "");
		boolean trouve = false;
		for (Demande demande : demandeEtageDeExterieur2) {
			if (demande.getEtage() <= min.getEtage() && demande.getDirection().equals(Constantes.HAUT)
					&& demande.getEtage() >= getEtageActuel()) {
				min = demande;
				trouve = true;
			}
		}
		if (trouve)
			return min;
		else
			return null;
	}

	/**
	 * Récupère la demande de monter inferieur à l'étage actuel la plus proche
	 * 
	 * @param demandeEtageDeExterieur2
	 * @return Demande
	 */
	private Demande demandeMonterInf(List<Demande> demandeEtageDeExterieur2) {
		Demande min = new Demande(0, "");
		boolean trouve = false;
		for (Demande demande : demandeEtageDeExterieur2) {
			if (demande.getEtage() >= min.getEtage() && demande.getDirection().equals(Constantes.HAUT)
					&& demande.getEtage() <= getEtageActuel()) {
				min = demande;
				trouve = true;
			}
		}
		if (trouve)
			return min;
		else
			return null;
	}

	/**
	 * Récupère la demande de déscendre superieur à l'étage actuel la plus
	 * proche
	 * 
	 * @param demandeEtageDeExterieur2
	 * @return Demande
	 */
	private Demande demandeDecenteSup(List<Demande> demandeEtageDeExterieur2) {
		Demande max = new Demande(100, "");
		boolean trouve = false;
		for (Demande demande : demandeEtageDeExterieur2) {
			if (demande.getEtage() <= max.getEtage() && demande.getDirection().equals(Constantes.BAS)
					&& demande.getEtage() >= getEtageActuel()) {
				max = demande;
				trouve = true;
			}
		}
		if (trouve)
			return max;
		else
			return null;
	}

	/**
	 * Récupère la demande de déscendre inferieur à l'étage actuel la plus
	 * proche
	 * 
	 * @param demandeEtageDeExterieur2
	 * @return Demande
	 */
	private Demande demandeDecenteInf(List<Demande> demandeEtageDeExterieur2) {
		Demande max = new Demande(0, "");
		boolean trouve = false;
		for (Demande demande : demandeEtageDeExterieur2) {
			if (demande.getEtage() >= max.getEtage() && demande.getDirection().equals(Constantes.BAS)
					&& demande.getEtage() <= getEtageActuel()) {
				max = demande;
				trouve = true;
			}
		}
		if (trouve)
			return max;
		else
			return null;
	}

	/**
	 * Méthoude demandeExterieurServie supprime une demande de la liste des
	 * demandes d'exterieur quand cette dernière est satisfète
	 * 
	 * @param etage
	 * @param typeDemande
	 */
	public void demandeExterieurServie(float etage, String typeDemande) {
		for (int i = 0; i < this.demandeEtageDeExterieur.size(); i++) {

			if (etage == this.demandeEtageDeExterieur.get(i).getEtage()
					&& typeDemande.equals(this.demandeEtageDeExterieur.get(i).getDirection())) {

				this.demandeEtageDeExterieur.remove(i);
				
				if(Constantes.HAUT.equals(typeDemande)) {
					MonterServiForImge = true;
				} 

				if(Constantes.BAS.equals(typeDemande)) {
					DecenteServiForImge = true;
				}
			}
		}
	}

	/**
	 * Méthoude demandeInterieurServi supprime une demande de la liste des
	 * demandes d'interieur quand cette dernière est satisfète
	 * 
	 * @param etage
	 */
	public void demandeInterieurServi(float etage) {

		for (int i = 0; i < this.demandeEtageDeInterieur.size(); i++) {
			if (etage == this.demandeEtageDeInterieur.get(i)) {
				this.demandeEtageDeInterieur.remove(i);
				
				InterieurServiForImge = true;
			}
		}
	}

	/**
	 * seDeplacer : Déplacement de la cabine (Vers le haut ou vers le bas)
	 */
	public void seDeplacer() {

		// Arrever à destination mais pas d'autre demandes dans les listes
		// (Exterieur et Interieur)
		if (getEtageActuel() == getEtageDestination() && getEtageDestination() == -1) {
			// ne rien faire
		} else if (getEtageDestination() != -1) {
			if (getEtageActuel() > getEtageDestination()) {
				if (!isArretUrgence) {
					descendre();
				}
			} else if (getEtageActuel() < getEtageDestination() && getEtageDestination() != -1) {
				if (!isArretUrgence) {
					monter();
				}
			}
		}
	}

	/**
	 * Methode gestionPortEtFilesDeDemande : - Gère la porte (Ouverture et
	 * fermetur). - Gére les listes des demandes (suppréssion des demandes
	 * servies). - Appel nextDemande
	 */
	public void gestionPortEtFilesDeDemande() {

		if (this.getEtageActuel() == this.getEtageDestination()) {
			try {

				Thread.sleep(1000);
				this.setEtatPorte(Constantes.EtatPorteOuverte);
				// simulateur.ouvrirPort();
				notifierLaVu();
				Thread.sleep(1005);

				this.setEtatPorte(Constantes.EtatPorteFermer);
				// simulateur.fermerPort();
				notifierLaVu();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			String typeDemande = "";
			if (Constantes.MONTER.equals(resultatDirection)) {
				typeDemande = Constantes.HAUT;
			} else if (Constantes.DESCENDRE.equals(resultatDirection)) {
				typeDemande = Constantes.BAS;
			}
			
			//Enlever la demande exterieur servie
			this.demandeExterieurServie(this.getEtageActuel(), typeDemande);

			//Enlever la demande interieur servie
			this.demandeInterieurServi(this.getEtageActuel());
			
			notifierLaVu();
		}

		// next demande
		if (Constantes.HAUT.equals(this.directionAsc)) {
			resultatDirection = this.nextDemande(Constantes.HAUT);
		}
		if (Constantes.BAS.equals(this.directionAsc)) {
			resultatDirection = this.nextDemande(Constantes.BAS);
		}
	}

	/**
	 * isArretUrgence()
	 * 
	 * @return boolean
	 */
	public boolean isArretUrgence() {
		return this.isArretUrgence;
	}

	/**
	 * getEtageDestination()
	 * 
	 * @return Float
	 */
	public Float getEtageDestination() {
		return etageDestination;
	}

	/**
	 * setEtageDestination
	 * 
	 * @param etageDestination
	 */
	public void setEtageDestination(float etageDestination) {
		this.etageDestination = etageDestination;
	}

	/**
	 * getEtageActuel()
	 * 
	 * @return float
	 */
	public float getEtageActuel() {
		return etageActuel;
	}

	/**
	 * setEtageActuel
	 * 
	 * @param etageActuel
	 */
	public void setEtageActuel(float etageActuel) {
		this.etageActuel = etageActuel;
	}

	/**
	 * getEtatPorte()
	 * 
	 * @return String
	 */
	public String getEtatPorte() {
		return etatPorte;
	}

	/**
	 * setEtatPorte
	 * 
	 * @param etatPorte
	 */
	public void setEtatPorte(String etatPorte) {
		this.etatPorte = etatPorte;
	}

	/**
	 * getDemandeEtageDeInterieur()
	 * 
	 * @return List<Float>
	 */
	public List<Float> getDemandeEtageDeInterieur() {
		return demandeEtageDeInterieur;
	}

	/**
	 * setDemandeEtageDeInterieur
	 * 
	 * @param demandeEtageDeInterieur
	 */
	public void setDemandeEtageDeInterieur(List<Float> demandeEtageDeInterieur) {
		this.demandeEtageDeInterieur = demandeEtageDeInterieur;
	}

	/**
	 * getDemandeEtageDeExterieur()
	 * 
	 * @return List<Demande>
	 */
	public List<Demande> getDemandeEtageDeExterieur() {
		return demandeEtageDeExterieur;
	}

	/**
	 * setDemandeEtageDeExterieur
	 * 
	 * @param demandeEtageDeExterieur
	 */
	public void setDemandeEtageDeExterieur(List<Demande> demandeEtageDeExterieur) {
		this.demandeEtageDeExterieur = demandeEtageDeExterieur;
	}

}