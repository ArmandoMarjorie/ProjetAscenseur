package Controleur;

import java.util.Timer;
import java.util.TimerTask;

import constante.Constantes;
import view.Simulateur;
import Model.AscenseurModel;

/**
 * Class controleur 
 * 
 */

public class Controleur {

	// le modele
	private AscenseurModel ascensseurModel;

	// la vue
	public Simulateur simulateur;

	private Timer timer;
	private TimerTask timerTask;

	/**
	 * Constructeur de la classe controleur dans le constructeur on Crée le
	 * modele et la vue, ensuite on associe l'observeur (similateur) à
	 * l'observable (ascenseurModele)
	 */

	public Controleur() {

		this.ascensseurModel = new AscenseurModel();

		this.simulateur = new Simulateur(this.ascensseurModel);

		// Ajouter l observer a l'observable
		this.ascensseurModel.addObserver(simulateur);
	}

	/**
	 * Fonction go execute les etapes nécessaires pour le déroulement de
	 * l'ascenseur en boucle infinie à l'aide d'un Timer Etapes : 
	 * 			- Se déplacer avec une unité 
	 * 			- Gérer les files d'attentes et la porte de l'assenseur 
	 * 			- Détécter la prochaine direction de l'ascenceur 
	 * 			- Notifier la vue pour afficher les nouvelles valeurs
	 */

	public void go() {

		timerTask = new TimerTask() {

			public void run() {

				// Déplacement de l'ascenseur

				ascensseurModel.seDeplacer();
				ascensseurModel.gestionPortEtFilesDeDemande();

				// Détection de la nouvelle direction de l'ascenseur

				if (ascensseurModel.compeurTentativedirection == ascensseurModel.nbEtages) {

					if (Constantes.BAS.equals(ascensseurModel.directionAsc)) {
						ascensseurModel.directionAsc = Constantes.HAUT;
					} else {
						ascensseurModel.directionAsc = Constantes.BAS;
					}

					ascensseurModel.compeurTentativedirection = 0;
				}

				// Notifier la vue pour afficher les nouvelles valeurs (etage,
				// prochain arret, ....)
				
				ascensseurModel.notifierLaVu();

			}
		};

		//Création d'un timer
		timer = new Timer(true);
		
		//Lancer les instructions du programme chaque 1600 secondes
		timer.scheduleAtFixedRate(timerTask, 0, 1600);
	}
}
