package constante;

/**
 * Constantes, contient les constantes qui sont utilisées dans l'application
 *
 */
public final class Constantes {

	public final static String EtatArretUrgence = "ARRETURGENCE";
	public final static String EtatPorteOuverte = "PORTEOUVERTE";
	public final static String EtatPorteFermer = "PORTEFERMER";
	public final static float UniteDeMouvement = (float) 0.5;

	public final static float UniteDeMouvementLente = (float) 0.1;

	public final static String HAUT = "HAUT";
	public final static String BAS = "BAS";

	public final static String MONTER = "MONTER";
	public final static String DESCENDRE = "DESCENDRE";
}
